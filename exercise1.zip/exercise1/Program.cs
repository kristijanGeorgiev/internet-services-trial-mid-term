﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Start inserting sheep presence (true/false/any other value for unknown):");
        string[] inputs = Console.ReadLine().Split(',');

        // Convert input strings to nullable booleans
        bool?[] sheepPresence = new bool?[inputs.Length];
        for (int i = 0; i < inputs.Length; i++)
        {
            sheepPresence[i] = ParseSheepPresence(inputs[i].Trim());
        }

        // Count sheep
        CountSheep(sheepPresence);
    }

    static bool? ParseSheepPresence(string input)
    {
        if (bool.TryParse(input, out bool result))
        {
            return result;
        }
        return null; // Presence unknown
    }

    static void CountSheep(bool?[] sheep)
    {
        int present = 0, absent = 0, unknown = 0;

        foreach (var s in sheep)
        {
            if (s == true)
                present++;
            else if (s == false)
                absent++;
            else
                unknown++;
        }

        Console.WriteLine($"{present} sheep are present");
        Console.WriteLine($"{absent} sheep are absent");
        Console.WriteLine($"{unknown} sheep presence unknown");
    }
}
