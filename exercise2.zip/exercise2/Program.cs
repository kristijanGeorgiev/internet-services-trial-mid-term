﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        Console.WriteLine("Start inserting students' ages (comma-separated, max 8 students):");

        try
        {
            string[] inputs = Console.ReadLine().Split(',');
            if (inputs.Length > 8)
            {
                Console.WriteLine("Error: Maximum number of students in a group is 8.");
                return;
            }

            int[] ages = inputs.Select(input => int.Parse(input.Trim())).ToArray();
            FindYoungestAndOldest(ages);
        }
        catch (FormatException)
        {
            Console.WriteLine("Invalid input. Please enter only numbers.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An unexpected error occurred: {ex.Message}");
        }
    }

    static void FindYoungestAndOldest(int[] ages)
    {
        int minAge = ages.Min();
        int maxAge = ages.Max();

        int minCount = ages.Count(age => age == minAge);
        int maxCount = ages.Count(age => age == maxAge);

        Console.Write($"Youngest student in the group is {minAge} years old. ");
        if (minCount > 1) Console.WriteLine($"There are {minCount} students at that age.");
        else Console.WriteLine();

        Console.Write($"Oldest student in the group is {maxAge} years old. ");
        if (maxCount > 1) Console.WriteLine($"There are {maxCount} students at that age.");
        else Console.WriteLine();
    }
}