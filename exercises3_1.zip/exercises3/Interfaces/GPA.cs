﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercises3.Interfaces
{
    class GPA : Student
    {
        public GPA(string name, string surname, int id, int yearOfStudy) : base(name, surname, id, yearOfStudy) { }
        public override void CalculateGPA()
        {
            if (Grades.Count == 0)
            {
                Console.WriteLine("No grades available to calculate GPA.");
                return;
            }
            double gpa = Grades.Average();
            double normalizedGPA = (gpa - 5) / 5 * 4; // Normalizing to 4.0 scale
            Console.WriteLine($"GPA: {normalizedGPA:F2}");
        }
    }
}
