﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercises3.Interfaces
{
    class Course : ICourse
    {
        private List<string> Courses = new List<string>();
        public void AddCourse(string course)
        {
            Courses.Add(course);
        }
        public void PrintCourses()
        {
            Console.WriteLine("Enrolled Courses: " + string.Join(", ", Courses));
        }

    }
}
