﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercises3.Interfaces
{
    public interface ICourse
    {
        void PrintCourses();
    }
}
