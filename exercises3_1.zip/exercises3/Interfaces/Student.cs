﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercises3.Interfaces
{
    class Student
    {
        private string Name;
        private string Surname;
        private int ID;
        private int YearOfStudy;
        public List<int> Grades { get; set; } = new List<int>();
        public Student() { }
        public Student(string name, string surname, int id, int yearOfStudy)
        {
            Name = name;
            Surname = surname;
            ID = id;
            YearOfStudy = yearOfStudy;
        }
        ~Student()
        {
            Console.WriteLine("Student object destroyed.");
        }
        public string GetName() => Name;
        public string GetSurname() => Surname;
        public int GetID() => ID;
        public int GetYearOfStudy() => YearOfStudy;
        public void PrintInfo()
        {
            Console.WriteLine($"Name: {Name}\nSurname: {Surname}\nID: {ID}\nYear of Study: {YearOfStudy}");
        }
        public virtual void CalculateGPA() { }
    }
}
