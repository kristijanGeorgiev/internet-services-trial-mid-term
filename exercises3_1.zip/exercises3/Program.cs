﻿// See https://aka.ms/new-console-template for more information
#region Interfaces
using exercises3.Interfaces;

try
{
    Console.Write("Please insert Student name: ");
    string name = Console.ReadLine();
    Console.Write("Please insert Student surname: ");
    string surname = Console.ReadLine();
    Console.Write("Please insert Student ID: ");
    int id = int.Parse(Console.ReadLine());
    Console.Write("Please insert Year of Study: ");
    int year = int.Parse(Console.ReadLine());
    GPA student = new GPA(name, surname, id, year);
    Console.WriteLine("Please start inserting student grades between 5 and 10. To stop, please insert \".\":");
    while (true)
    {
        string input = Console.ReadLine();
        if (input == ".")
            break;
        if (int.TryParse(input, out int grade))
        {
            if (grade >= 5 && grade <= 10)
                student.Grades.Add(grade);
            else
                Console.WriteLine("You have inserted an incorrect grade. Allowed grades should be between 5 and 10!");
        }
        else
        {
            Console.WriteLine("Invalid input. Please enter a number between 5 and 10.");
        }
    }
    student.PrintInfo();
    student.CalculateGPA();
}
catch (FormatException)
{
    Console.WriteLine("Invalid input detected. Please enter valid numeric values.");
}
catch (Exception ex)
{
    Console.WriteLine($"An unexpected error occurred: {ex.Message}");
}
#endregion